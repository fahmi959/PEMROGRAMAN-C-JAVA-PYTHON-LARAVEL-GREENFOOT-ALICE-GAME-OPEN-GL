<?php

namespace App\Models;



class Post
{
  private static $blog_posts =  [

    [   "title" => "Judul Post Pertama" ,
        "slug" => "judul-post-pertama" ,
        "author" => "Fahmi Ardiansyah" ,
        "body" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, eveniet! Ab eligendi provident aut dicta sequi repudiandae rem nihil hic minus, molestiae labore ullam ea quos. Quia enim consequuntur, blanditiis dolor doloremque omnis repellendus ducimus ea nostrum suscipit quod eos doloribus, ab id quidem rerum voluptatem aliquam natus optio facilis nobis vel itaque ratione nam? Tempora minus ad mollitia illo quia esse officia asperiores et iusto, quaerat neque explicabo exercitationem velit placeat sequi commodi in aperiam, magni eos sed architecto!"
   ] ,
   [
       "title" => "Judul Post Kedua" ,
       "slug" => "judul-post-kedua" ,
       "author" => "Lord Baeelah" ,
       "body" => "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, eveniet! Ab eligendi provident aut dicta sequi repudiandae rem nihil hic minus, molestiae labore ullam ea quos. Quia enim consequuntur, blanditiis dolor doloremque omnis repellendus ducimus ea nostrum suscipit quod eos doloribus, ab id quidem rerum voluptatem aliquam natus optio facilis nobis vel itaque ratione nam? Tempora minus ad mollitia illo quia esse officia asperiores et iusto, quaerat neque explicabo exercitationem velit placeat sequi commodi in aperiam, magni eos sed architecto!"
   ]
   ] ;

   public static function all() {
       return collect(self :: $blog_posts) ;
   }


   public static function find($slug)
   {
        $posts = static :: all() ;
    //    $post = [];
    //    foreach($posts as $p){
    //        if($p["slug"] === $slug){
    //            $post = $p;
    //        }
    //    }
       return $posts -> firstWhere('slug' , $slug);
   }
}
