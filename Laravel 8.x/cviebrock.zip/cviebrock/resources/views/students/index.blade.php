@extends('dashboard.layouts.main')
@section('container')
<div class="container mt-4">
	<div class="d-flex justify-content-end">
        <a href="{{ route('student.create') }}" class="btn btn-success mb-2">Tambah Role</a>
	</div>
	<div class="mt-3">
			@if (session('success'))
				<div class="alert alert-success">
					{{ session('success') }}
				</div>
			@endif
			
			@if (session('error'))
                <div class="alert alert-error">
                    {{ session('error') }}
                </div>
                @endif
		 <table class="table table-hover" id="users-list">
		   <thead>
			  <tr>
				 <th>Role Id</th>
				 <th>Jenis Role</th>
				 <th>Jenis Kelamin</th>
				 <th>Umur</th>
				 <th>Aksi</th>
			  </tr>
		   </thead>
		   <tbody>
			 @forelse ($students as $student)
			  <tr>
				 <td>{{ $student->id }}</td>
				 <td>{{ $student->nama }}</td>
				 <td>{{ $student->jenis_kelamin }}</td>
				 <td>{{ $student->umur }}</td>
				 <td>
					<form onsubmit="return confirm('Apakah Anda Yakin ?');"
						action="{{ route('student.destroy', $student->id) }}" method="POST">
						<a href="{{ route('student.edit', $student->id) }}"
							class="btn btn-sm btn-primary">EDIT</a>
						@csrf
						@method('DELETE')
						<button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
					</form>
					
				  </td>
			  </tr>
			  @empty
				<tr>
					<td class="text-center text-mute" colspan="5">Data Kosong</td>
				</tr>
			 @endforelse
		   </tbody>
		 </table>
	  </div>
</div>
<script>
    $(document).ready( function () {
      $('#students-list').DataTable();
  } );
</script>
@endsection
