@extends('dashboard.layouts.main')

@section('container')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">Validasi Terhadap Pemesanan Pengguna</h1>
</div>
  <div class="table-responsive col-lg-11">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Divisi</th>
          <th scope="col">Nama Kebutuhan</th>
          <th scope="col">Kategori Pesanan</th>
          <th scope="col">Kode Pemesanan</th>
          <th scope="col">Jumlah Kebutuhan</th>
          <th scope="col">Harga</th>
          <th scope="col">Validasi Pemesanan</th>

        </tr>

      </thead>
      <tbody>



          @foreach($validasi as $v)

          <tr>
              <td>{{ $loop->iteration }}</td>
              <td>{{ $v->category->nama_divisi }}</td>
              <td>{{ $v->title }}</td>
              <td>{{ $v->category->kategori_pesanan }}</td>
              <td>{{ $v->category->nama_divisi }}-{{ $v->category->slug }}-{{ $loop->iteration }}</td>
              <td>{{ $v->jumlah_kebutuhan }}</td>
              <td>{{ $v->harga }}</td>
              <td>
                <select name="validasi" class="form-control" required>
                    <option value="Barang Belum Diterima" selected>Barang Belum Diterima</option>
                    <option value="Barang Telah Diterima">Barang Telah Diterima</option>
                </select>
                {{-- @if($v->validasi==1)
                <a href="{{url('validasi_pesanan/validasi/0')}}/{{$validasi->id}}"><button type="button" class="btn btn-primary">Active</button></a>
             @elseif($v->validasi==0)
                <a href="{{url('validasi_pesanan/validasi/1')}}/{{$validasi->id}}"><button type="button" class="btn btn-warning">Deactive</button></a>
            @endif --}}

        </tr>

            @endforeach

      </tbody>



    </table>
  </div>

  <div class="container-fluid text-center">
    <h6>Total Harga</h6>
</div>


@endsection
