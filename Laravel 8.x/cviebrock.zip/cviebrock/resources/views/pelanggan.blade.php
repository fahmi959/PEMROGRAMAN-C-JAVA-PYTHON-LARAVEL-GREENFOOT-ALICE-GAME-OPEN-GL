<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>CRUD</title>
    </head>
    
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    Data Pelanggan
                    <form action="/pelanggan/cari" method="GET">
                        <input type="text" name="cari" placeholder="Cari Pelanggan .." value="{{ old('cari') }}">
                        <input type="submit" value="CARI">
                    </form>
                </div>
                
                <div class="card-body">
                    <a href="/pelanggan/tambah" class="btn btn-primary">Input Pelanggan Baru</a>
                    <br/>
                    <br/>
                    
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Id Pelanggan</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Telepon</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            @foreach($pelanggan as $p)
                            <tr>
                                <td>{{ $p->Kode_pelanggan}}</td>
                                <td>{{ $p->Nama_pelanggan }}</td>
                                <td>{{ $p->Alamat_pelanggan }}</td>
                                <td>{{ $p->Telpon_pelanggan	 }}</td>
                                <td> 
                                    <a href="/pelanggan/edit/{{ $p->id }}" class="btn btn-warning">Edit</a>
                                    <a href="/pelanggan/hapus/{{ $p->id }}" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <br/>
                    Halaman : {{ $pelanggan->currentPage() }} <br/>
                    Jumlah Data : {{ $pelanggan->total() }} <br/>
                    Data Per Halaman : {{ $pelanggan->perPage() }} <br/>
                    {{ $pelanggan->links() }}
                </div>
            </div>
        </div>
    </body>
</html>

