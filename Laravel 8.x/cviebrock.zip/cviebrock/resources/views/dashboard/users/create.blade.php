@extends('dashboard.layouts.main')

@section('container')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Tambahkan Pengguna Baru</h1>

  </div>


<div class="col-lg-8">

    <form method="post" action="/dashboard/users" class="mb-5">
        @csrf


          <div class="mb-3">
            <label for="name" class="form-label">Nama Pengguna</label>
            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name"
            name="name" required autofocus value="{{ old('name') }}">
            @error('name')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror



          <div class="mt-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" class="form-control @error('email') is-invalid @enderror" id="email"
            name="email" required autofocus value="{{ old('email') }}">
            @error('email')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror


          <div class=" mt-4">
            {{--  <label for="level" class=" col-form-label text-md-end">Level</label>


                <input id="level" type="level" class="form-control @error('level') is-invalid @enderror" name="level" value="{{ old('level') }}" required autocomplete="level" autofocus>

                @error('level')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>  --}}

        <div class= "mb-3 mt-4">
            <label for="level">Pilih Level :  </label>
            <select name="level" id="level" type="level" placeholder="level" required>
            <option value="">Silahkan pilih akses role pengguna</option>
              <option value="admin">Admin</option>
              <option value="manajer_eksekutif">Manajer Eskekutif</option>
              <option value="vendor">Vendor</option>
              <option value="user">User Biasa</option>
            </select></div>

          <div class="mt-3">

            <label for="password">Password</label>
            <input id="password" placeholder="Password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror

                                    <div class="mt-3">
            <label for="password">Konfirmasi Password</label>
            <input id="password-confirm" placeholder="Password confirmation" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">


            @error('password')
            <div class="invalid-feedback">
            {{ $message }}
          </div>

          @enderror


          <div class="mt-3">


        <button type="submit" class="btn btn-danger text-md-center mt-3">Buat Pengguna Baru</button>
      </form>






</div>


@endsection
