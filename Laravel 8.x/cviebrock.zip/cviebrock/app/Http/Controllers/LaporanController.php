<?php

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\Category;
use Illuminate\Support\Str;
use Cviebrock\EloquentSluggable\Services\SlugService;

class LaporanController extends Controller
{

    public function index()
    {
        $laporan = Post ::latest()->get();
        return view('laporan', ['laporan'=>$laporan]);
    }
}