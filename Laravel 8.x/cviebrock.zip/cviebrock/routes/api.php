<?php

use App\Models\Post;
use App\Models\Category;
use App\Models\Validasi;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('posts' , function(){
    return Post::all();
}) ;

Route::post('posts' , function(){
    return Post::create(request()->all());
}) ;

Route::patch('posts' , function(){
    return Post::patch(request()->all());
}) ;



Route::delete('posts/{post}' , function (Post $post){
    $post->delete();
return  'Post berhasil dihapus , Sukses Bos' ;
});


Route::get('categories' , function(){
    return Category::all();
}) ;



Route::post('categories' , function(){
    return Category::create(request()->all());
}) ;

Route::patch('categories' , function(){
    return Category::patch(request()->all());
}) ;



Route::delete('categories/{category}' , function (Category $category){
    $category->delete();
return  'Category berhasil dihapus , Sukses Bos' ;
});


Route::get('validasis' , function(){
    return Validasi::all();
}) ;



Route::post('validasis' , function(){
    return Validasi::create(request()->all());
}) ;

Route::patch('validasis' , function(){
    return Validasi::patch(request()->all());
}) ;



Route::delete('validasis/{validasi}' , function (Validasi $validasi){
    $validasi->delete();
return  'Validasi berhasil dihapus , Sukses Bos' ;
});


Route::get('users' , function(){
    return User::all();
}) ;



Route::post('users' , function(){
    return User::create(request()->all());
}) ;

