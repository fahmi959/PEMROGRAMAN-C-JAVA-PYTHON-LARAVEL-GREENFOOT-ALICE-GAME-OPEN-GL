<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Guru;

class GuruController extends Controller
{
    public function index()
    {
        // mengambil data dari table guru
        $guru = DB::table('guru')->paginate(10);
        
        // mengirim data guru ke view index
        return view('guru',['guru' => $guru]);
    }
    
    public function tambah()
    {
        return view('guru_tambah');
    }
    
    public function simpan(Request $request)
    {
        $this->validate($request,[
            'nip' => 'required',
            'nama' => 'required',
            'alamat' => 'required'
        ]);
        
        Guru::create([
            'nip' => $request->nip,
            'nama' => $request->nama,
            'alamat' => $request->alamat
        ]);
        
        return redirect('/guru');
    }

    public function edit($id)
 {
     $guru = Guru::find($id);
     return view('guru_edit', ['guru' => $guru]);
 }

 public function update($id, Request $request)
{
    $this->validate($request,[
        'nip' => 'required',
        'nama' => 'required',
        'alamat' => 'required'
    ]);
    
    $guru = Guru::find($id);
    $guru->nip = $request->nip;
    $guru->nama = $request->nama;
    $guru->alamat = $request->alamat;
    $guru->save();
    
    return redirect('/guru');
}
public function delete($id)
{
    $guru = Guru::find($id);
    $guru->delete();
    
    return redirect('/guru');
}

public function cari(Request $request)
    {
        // menangkap data pencarian
        $cari = $request->cari;
        
        // mengambil data dari table guru sesuai pencarian data
        $guru = DB::table('guru')
        ->where('nama','like',"%".$cari."%")
        ->paginate();
        
        // mengirim data pegawai ke view index
        return view('guru',['guru' => $guru]);
    }
}