<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Pelanggan;

class PelangganController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {
        // mengambil data dari table pelanggan
        $pelanggan = DB::table('pelanggan')->paginate(10);
        
        // mengirim data pelanggan ke view index
        return view('pelanggan',['pelanggan' => $pelanggan]);
    }
    
    public function tambah()
    {
        return view('pelanggan_tambah');
    }
    
    public function simpan(Request $request)
    {
        $this->validate($request,[
            'Kode_pelanggan' => 'required',
            'Nama_pelanggan' => 'required',
            'Alamat_pelanggan' => 'required',
            'Telpon_pelanggan' => 'required'
        ]);
        
        
        Pelanggan::create([
            'Kode_pelanggan' => $request->Kode_pelanggan,
            'Nama_pelanggan' => $request->Nama_pelanggan,
            'Alamat_pelanggan' => $request->Alamat_pelanggan,
            'Telpon_pelanggan' => $request->Telpon_pelanggan
        ]);
        
        return redirect('/pelanggan');
    }

    public function edit($id)
 {
     $pelanggan = Pelanggan::find($id);
     return view('pelanggan_edit', ['pelanggan' => $pelanggan]);
 }

 public function update($id, Request $request)
{
    $this->validate($request,[
        'Kode_pelanggan' => 'required',
        'Nama_pelanggan' => 'required',
        'Alamat_pelanggan' => 'required',
        'Telpon_pelanggan' => 'required'
    ]);
    
    $pelanggan = pelanggan::find($id);
    $pelanggan->Kode_pelanggan = $request->Kode_pelanggan;
    $pelanggan->Nama_pelanggan = $request->Nama_pelanggan;
    $pelanggan->Alamat_pelanggan = $request->Alamat_pelanggan;
    $pelanggan->Telpon_pelanggan = $request->Telpon_pelanggan;
    $pelanggan->save();
    
    return redirect('/pelanggan');
}
public function delete($id)
{
    $pelanggan = pelanggan::find($id);
    $pelanggan->delete();
    
    return redirect('/pelanggan');
}

public function cari(Request $request)
    {
        // menangkap data pencarian
        $cari = $request->cari;
        
        // mengambil data dari table pelanggan sesuai pencarian data
        $pelanggan = DB::table('pelanggan')
        ->where('Nama_pelanggan','like',"%".$cari."%")
        ->paginate();
        
        // mengirim data pegawai ke view index
        return view('pelanggan',['pelanggan' => $pelanggan]);
    }
}