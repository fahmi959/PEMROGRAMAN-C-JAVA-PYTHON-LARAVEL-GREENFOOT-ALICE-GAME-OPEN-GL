@extends('dashboard.layouts.main')

@section('container')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">Validasi Terhadap Pemesanan Pengguna</h1>
</div>
  <div class="table-responsive col-lg-11">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Divisi</th>
          <th scope="col">Nama Kebutuhan</th>
          <th scope="col">Kategori Pesanan</th>
          <th scope="col">Kode Pemesanan</th>
          <th scope="col">Jumlah Kebutuhan</th>
          <th scope="col">Harga</th>

        </tr>

      </thead>
      <tbody>



          @foreach($laporan as $l)

          <tr>
              <td>{{ $loop->iteration }}</td>
              <td>{{ $l->category->nama_divisi }}</td>
              <td>{{ $l->title }}</td>
              <td>{{ $l->category->kategori_pesanan }}</td>
              <td>{{ $l->category->nama_divisi }}-{{ $l->category->slug }}-{{ $loop->iteration }}</td>
              <td>{{ $l->jumlah_kebutuhan }}</td>
              <td>{{ $l->harga }}</td>

        </tr>

            @endforeach

      </tbody>



    </table>
  </div>

  <div class="container-fluid text-center">
    <h6>Total Harga</h6>
</div>


@endsection
