<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use App\Models\Invoice;

class InvoiceController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {
        // mengambil data dari table invoice
        $invoice = DB::table('invoice')->paginate(10);
        
        // mengirim data invoice ke view index
        return view('invoice',['invoice' => $invoice]);
    }
    
    public function tambah()
    {
        return view('invoice_tambah');
    }
    
    public function simpan(Request $request)
    {
        $this->validate($request,[
            'Kode_invoice' => 'required',
            'Id_pelanggan' => 'required',
            'Nama_invoice' => 'required',
            'Jumlah_invoice' => 'required',
            'Harga_invoice' => 'required',
            'Ppn_invoice' => 'required',
            'Total_invoice' => 'required'
        ]);
        
        
        Invoice::create([
            'Kode_invoice' => $request->Kode_invoice,
            'Id_pelanggan' => $request->Id_pelanggan,
            'Nama_invoice' => $request->Nama_invoice,
            'Jumlah_invoice' => $request->Jumlah_invoice,
            'Harga_invoice' => $request->Harga_invoice,
            'Ppn_invoice' => $request->Ppn_invoice,
            'Total_invoice' => $request->Total_invoice
        ]);
        
        return redirect('/invoice');
    }

    public function edit($id)
 {
     $invoice = Invoice::find($id);
     return view('invoice_edit', ['invoice' => $invoice]);
 }

 public function update($id, Request $request)
{
    $this->validate($request,[
        'Kode_invoice' => 'required',
        'Id_pelanggan' => 'required',
        'Nama_invoice' => 'required',
        'Jumlah_invoice' => 'required',
        'Harga_invoice' => 'required',
        'Ppn_invoice' => 'required',
        'Total_invoice' => 'required'
    ]);
    
    $invoice = invoice::find($id);
    $invoice->Kode_invoice = $request->Kode_invoice;
    $invoice->Id_pelanggan = $request->Id_pelanggan;
    $invoice->Nama_invoice = $request->Nama_invoice;
    $invoice->Jumlah_invoice = $request->Jumlah_invoice;
    $invoice->Harga_invoice = $request->Harga_invoice;
    $invoice->Ppn_invoice = $request->Ppn_invoice;
    $invoice->Total_invoice = $request->Total_invoice;
    $invoice->save();
    
    return redirect('/invoice');
}
public function delete($id)
{
    $invoice = invoice::find($id);
    $invoice->delete();
    
    return redirect('/invoice');
}

public function cari(Request $request)
    {
        // menangkap data pencarian
        $cari = $request->cari;
        
        // mengambil data dari table invoice sesuai pencarian data
        $invoice = DB::table('invoice')
        ->where('Nama_invoice','like',"%".$cari."%")
        ->paginate();
        
        // mengirim data pegawai ke view index
        return view('invoice',['invoice' => $invoice]);
    }
}


