<?php

use App\Models\Post;
use App\Models\Category;
use Faker\Provider\Lorem;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\LaporanController;





// 2 dibawah ini tidak penting bisa dihapus

use function Symfony\Component\Translation\t;




Route::get('/', function () {
    return view('auth.login');
});

Route::get('/pelanggan', 'PelangganController@index');

Route::get('/pelanggan/tambah', 'PelangganController@tambah');

Route::post('/pelanggan/simpan', 'PelangganController@simpan');

Route::get('/pelanggan/edit/{id}', 'PelangganController@edit');

Route::put('/pelanggan/update/{id}', 'PelangganController@update');

Route::get('/pelanggan/hapus/{id}', 'PelangganController@delete');

Route::get('/pelanggan/cari','PelangganController@cari');
Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');




Route::get('/invoice', 'InvoiceController@index');

Route::get('/invoice/tambah', 'InvoiceController@tambah');

Route::post('/invoice/simpan', 'InvoiceController@simpan');

Route::get('/invoice/edit/{id}', 'InvoiceController@edit');

Route::put('/invoice/update/{id}', 'InvoiceController@update');

Route::get('/invoice/hapus/{id}', 'InvoiceController@delete');

Route::get('/invoice/cari','InvoiceController@cari');
Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');


Route::get('/posts', [PostController :: class , 'index']);

// halaman single post
Route :: get('posts/{post:slug}' , [PostController :: class, 'show']);

Route :: get('/categories' , function(){
    return view('categories' , [
        'title' => 'Post Categories' ,
        'active' => 'categories' ,
        'categories' => Category::all()
    ]);
});

Route :: get('/dashboard', function (){
    return view('dashboard.index');
});



Route :: get('/dashboard/posts/checkSlug' , [DashboardPostController::class , 'checkSlug'])->middleware('auth');

Route :: resource('/dashboard/posts' , DashboardPostController::class)->middleware('auth');

Route::get('/validasi_pesanan','ValidasiController@index');

Route::get('/laporan', [LaporanController::class, 'index']);




Route::resource('dashboard/student', StudentController::class);




// Route::resource('/dashboard/categories' , AdminCategoryController::class)->except('show')->middleware('admin');
Route::resource('/dashboard/categories' , AdminCategoryController::class)->except('show');

Route::resource('/dashboard/users' , UserController::class)->except('show');
