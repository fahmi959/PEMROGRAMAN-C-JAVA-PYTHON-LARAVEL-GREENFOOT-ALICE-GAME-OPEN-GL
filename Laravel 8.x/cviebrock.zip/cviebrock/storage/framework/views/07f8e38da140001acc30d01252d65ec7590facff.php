<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="background-color: #191970">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">

            <hr class="mt-3">
            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard') ? 'active' : ''); ?> font-weight-bold"
                    aria-current="page" href="/dashboard"><i class="fas fa-tachometer-alt"></i>
                    <span data-feather="home"></span> Dashboard </a>
            </li>



            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/posts*') ? 'active' : ''); ?>" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <hr class="mt-0">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ceo')): ?>

            <li class="nav-item">
                <a class="nav-link text-muted">Manajer Eksekutif</a>
            </li>


            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>


            <hr class="mt-0">


            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/categories*') ? 'active' : ''); ?>" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>
            </li>

            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/posts*') ? 'active' : ''); ?>" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>



            <hr class="mt-0">



            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/categories*') ? 'active' : ''); ?>" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>
            </li>

            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manajer_eksekutif')): ?>

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/posts*') ? 'active' : ''); ?>" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>

            <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor')): ?>



            <hr class="mt-0">
            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/categories*') ? 'active' : ''); ?>" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>


            <hr class="mt-0">

            <?php endif; ?>


            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Report</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/invoice"><i class="fas fa-receipt"></i>
                    <span data-feather="bar-chart-2"></span> Data Invoice </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/pelanggan"><i class="	fas fa-id-card"></i>
                    <span data-feather="bar-chart-2"></span> Data Pelanggan </a>
            </li>



            <li class="nav-item">
                <a class="nav-link text-light" href="/laporan"><i class="fas fa-file-alt"></i>
                    <span data-feather="bar-chart-2"></span> Laporan </a>
            </li>

            <hr class="mt-0">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ceo')): ?>

            
            <li class="nav-item">
                <a class="nav-link text-muted">Permission</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/users*') ? 'active' : ''); ?>" href="/dashboard/users"><i class="	fas fa-user-shield "></i>
                    <span data-feather="shopping-cart"></span> Perizinan Pengguna </a>
            </li>


            <?php endif; ?>

            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Level</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light <?php echo e(Request :: is('dashboard/students*') ? 'active' : ''); ?>"
                href="/dashboard/student""><i class="fas fa-user-tag"></i>
                    <span data-feather="users"></span> Role </a>
            </li>

            <br>
            <br>


            <?php if(session()->has('ADMIN_LOGIN') or session()->has('STAFF-PRODUCT')): ?>
            <?php endif; ?>

        </ul>

    </div>
</nav>
<?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>