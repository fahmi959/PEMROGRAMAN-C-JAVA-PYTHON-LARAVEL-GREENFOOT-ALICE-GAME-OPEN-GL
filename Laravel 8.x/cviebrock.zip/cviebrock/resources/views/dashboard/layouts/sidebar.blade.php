<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="background-color: #191970">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">

            <hr class="mt-3">
            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard') ? 'active' : '' }} font-weight-bold"
                    aria-current="page" href="/dashboard"><i class="fas fa-tachometer-alt"></i>
                    <span data-feather="home"></span> Dashboard </a>
            </li>



            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/posts*') ? 'active' : '' }}" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <hr class="mt-0">
            @can('ceo')

            <li class="nav-item">
                <a class="nav-link text-muted">Manajer Eksekutif</a>
            </li>


            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>


            <hr class="mt-0">


            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/categories*') ? 'active' : '' }}" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>
            </li>

            @elsecan('admin')

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/posts*') ? 'active' : '' }}" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>



            <hr class="mt-0">



            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/categories*') ? 'active' : '' }}" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>
            </li>

            @elsecan('manajer_eksekutif')

            <li class="nav-item">
                <a class="nav-link text-muted">Transaksi</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/posts*') ? 'active' : '' }}" href="/dashboard/posts"><i class="fas fa-people-carry"></i>
                    <span data-feather="shopping-cart"></span>Ajukan Pesanan </a>
            </li>

            <li class="nav-item mt-0">
                <a class="nav-link text-light"
                    href="#"><i class="fas fa-list-alt"></i>
                    <span data-feather="file-text"></span> Seleksi Pesanan</a>
            </li>

            @elsecan('vendor')



            <hr class="mt-0">
            <li class="nav-item">
                <a class="nav-link text-muted">Vendor</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/validasi_pesanan"><i class="fas fa-check-double"></i>
                    <span data-feather="layers"></span> Validasi Pesanan </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/categories*') ? 'active' : '' }}" href="/dashboard/categories"><i class="	fas fa-file-signature"></i>
                    <span data-feather="shopping-cart"></span> Setting Kategori </a>


            <hr class="mt-0">

            @endcan


            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Report</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/invoice"><i class="fas fa-receipt"></i>
                    <span data-feather="bar-chart-2"></span> Data Invoice </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light" href="/pelanggan"><i class="	fas fa-id-card"></i>
                    <span data-feather="bar-chart-2"></span> Data Pelanggan </a>
            </li>



            <li class="nav-item">
                <a class="nav-link text-light" href="/laporan"><i class="fas fa-file-alt"></i>
                    <span data-feather="bar-chart-2"></span> Laporan </a>
            </li>

            <hr class="mt-0">

            @can('ceo')

            {{--  <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">Manajer Eksekutif</a></h6>  --}}
            <li class="nav-item">
                <a class="nav-link text-muted">Permission</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/users*') ? 'active' : '' }}" href="/dashboard/users"><i class="	fas fa-user-shield "></i>
                    <span data-feather="shopping-cart"></span> Perizinan Pengguna </a>
            </li>


            @endcan

            <hr class="mt-0">

            <li class="nav-item">
                <a class="nav-link text-muted">Level</a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-light {{ Request :: is('dashboard/students*') ? 'active' : '' }}"
                href="/dashboard/student""><i class="fas fa-user-tag"></i>
                    <span data-feather="users"></span> Role </a>
            </li>

            <br>
            <br>


            @if (session()->has('ADMIN_LOGIN') or session()->has('STAFF-PRODUCT'))
            @endif

        </ul>

    </div>
</nav>
