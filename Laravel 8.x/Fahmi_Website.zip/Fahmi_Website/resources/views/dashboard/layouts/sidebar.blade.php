<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link {{ Request :: is('dashboard') ? 'active' : '' }}" aria-current="page" href="/dashboard">
            <span data-feather="home"></span> Dashboard </a> </li>


        <li class="nav-item">
            <a class="nav-link {{ Request :: is('dashboard/posts*') ? 'active' : '' }}" href="/dashboard/posts">
              <span data-feather="shopping-cart"></span> Tambah Pesanan </a>
          </li>

        <li class="nav-item">
          <a class="nav-link " href="#">
            <span data-feather="file-text"></span>  Seleksi Pesanan </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="layers"></span> Validasi Pesanan </a>
          </li>






        <li class="nav-item">
          <a class="nav-link" href="#">
            <span data-feather="bar-chart-2"></span> Laporan  </a>
        </li>




        <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="users"></span> Pengguna </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="users"></span> Level </a>
          </li>
          @if (session()->has('ADMIN_LOGIN') or session()->has('STAFF-PRODUCT'))
@endif

      </ul>




    </div>
  </nav>
