<?php

namespace App\Http\Controllers;

use App\Models\Validasi;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\Category;
use Illuminate\Support\Str;
use Cviebrock\EloquentSluggable\Services\SlugService;
use Storage;
class ValidasiController extends Controller
{
    public function index()
    {
        $validasi = Post :: where('user_id', auth()->user()->id)->get();
        return view('validasi_pesanan', ['validasi'=>$validasi]);
    }
    // public function validasi(Request $request,$validasi,$id){
    //     $valid=Validasi::find($id);
    //     $valid->validasi=$validasi;
    //     $valid->save();
    //     $request->session()->flash('message','Status Penerimaan Diperbarui');
    //     return redirect('validasi_pesanan');
    // }
}