<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>DATA PELANGGAN</title>
    </head>

    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data Pelanggan - <strong>TAMBAH DATA</strong>
                </div>
                
                <div class="card-body">
                    <a href="/pelanggan" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    
                    <form method="post" action="/pelanggan/simpan">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label>Id Pelanggan</label>
                            <input type="text" name="Kode_pelanggan" class="form-control" placeholder="Id Pelanggan ...">
                            <?php if($errors->has('Kode_pelanggan')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('Kode_pelanggan')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="Nama_pelanggan" class="form-control" placeholder="Nama Pelanggan ...">
                            <?php if($errors->has('Nama_pelanggan')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('Nama_pelanggan')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="Alamat_pelanggan" class="form-control" placeholder="Alamat Pelanggan ..."></textarea>
                            <?php if($errors->has('Alamat_pelanggan')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('Alamat_pelanggan')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Telepon Pelanggan</label>
                            <input type="text" name="Telpon_pelanggan" class="form-control" placeholder="Telepon Pelanggan ...">
                            <?php if($errors->has('Telpon_pelanggan')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('Telpon_pelanggan')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/pelanggan_tambah.blade.php ENDPATH**/ ?>