

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">Validasi Terhadap Pemesanan Pengguna</h1>
</div>
  <div class="table-responsive col-lg-11">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">No.</th>
          <th scope="col">Nama Divisi</th>
          <th scope="col">Nama Kebutuhan</th>
          <th scope="col">Kategori Pesanan</th>
          <th scope="col">Kode Pemesanan</th>
          <th scope="col">Jumlah Kebutuhan</th>
          <th scope="col">Harga</th>

        </tr>

      </thead>
      <tbody>



          <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($l->category->nama_divisi); ?></td>
              <td><?php echo e($l->title); ?></td>
              <td><?php echo e($l->category->kategori_pesanan); ?></td>
              <td><?php echo e($l->category->nama_divisi); ?>-<?php echo e($l->category->slug); ?>-<?php echo e($loop->iteration); ?></td>
              <td><?php echo e($l->jumlah_kebutuhan); ?></td>
              <td><?php echo e($l->harga); ?></td>

        </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>



    </table>
  </div>

  <div class="container-fluid text-center">
    <h6>Total Harga</h6>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/laporan.blade.php ENDPATH**/ ?>