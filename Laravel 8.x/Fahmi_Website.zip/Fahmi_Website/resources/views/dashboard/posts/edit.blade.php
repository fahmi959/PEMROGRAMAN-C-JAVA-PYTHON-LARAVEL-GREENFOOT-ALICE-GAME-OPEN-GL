@extends('dashboard.layouts.main')

@section('container')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Post</h1>

  </div>


<div class="col-lg-8">

    <form method="post" action="/dashboard/posts/{{ $post->slug }}" class="mb-5">
        @method('put')
        @csrf

       <div class="mb-3">
            <label for="category" class="form-label">Nama Divisi</label>
            <select class="form-select" name="category_id">
                @foreach($categories as $category)
                @if(old('category_id') == $category->id)
            <option value ="{{ $category->id }}" selected>{{ $category->nama_divisi }}</option>
                @else
                <option value ="{{ $category->id }}">{{ $category->nama_divisi }}</option>
                @endif
                @endforeach
              </select>
          </div>

          <div class="mb-3">
            <label for="title" class="form-label">Nama Kebutuhan</label>
            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title"
            name="title" required autofocus value="{{ old('title' , $post->title) }}">
            @error('title')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror

        {{--  <div class="mb-3">
          <label for="nama_kebutuhan" class="form-label">Nama Kebutuhan</label>
          <input type="text" class="form-control @error('nama_kebutuhan') is-invalid @enderror" id="nama_kebutuhan"
          name="nama_kebutuhan" >
          @error('nama_kebutuhan')
          <div class="invalid-feedback">
          {{ $message }}
        </div>
        @enderror  --}}



          <div class="mt-3">
            <label for="category" class="form-label">Kategori Barang</label>
            <select class="form-select" name="category_id">
                @foreach($categories as $category)
                @if(old('category_id') == $category->id)
            <option value ="{{ $category->id }}" selected>{{ $category->kategori_barang }}</option>
                @else
                <option value ="{{ $category->id }}">{{ $category->kategori_barang }}</option>
                @endif
                @endforeach
              </select>
          </div>

          <div class="mb-3">
            <label for="slug" class="form-label">Kode</label>
            <input type="text" class="form-control @error('slug') is-invalid @enderror" id="slug" readonly
            name="slug" required autofocus value="{{ old('title' , $post->slug) }}">
            @error('slug')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror


          <div class="mb-3">
            <label for="jumlah_kebutuhan" class="form-label">Jumlah_Kebutuhan</label>
            <input type="text" class="form-control @error('jumlah_kebutuhan') is-invalid @enderror" id="jumlah_kebutuhan"
            name="jumlah_kebutuhan" required autofocus value="{{ old('jumlah_kebutuhan' , $post->jumlah_kebutuhan) }}">
            @error('jumlah_kebutuhan')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror

          <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" class="form-control @error('harga') is-invalid @enderror" id="harga"
            name="harga" required autofocus value="{{ old('harga' , $post->harga) }}">
            @error('harga')
            <div class="invalid-feedback">
            {{ $message }}
          </div>
          @enderror

          <div class="mt-3">
            <label for="body" class="form-label">Keterangan / Penjelasan</label>
            @error('body')
            <p class="text-danger">{{ $message }}</p>
            @enderror
            <input id="body" type="hidden" name="body" value="{{ old('body' , $post->body) }}">
            <trix-editor input="body"></trix-editor>
          </div>

        <div class="mb-3 form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Buat Pesanan Baru</button>
      </form>

</div>


<script>
    const nama_kebutuhan = document.querySelector('#nama_kebutuhan');
    const slug = document.querySelector('#slug');

    nama_kebutuhan.addEventListener('change' , function(){
        fetch('/dashboard/posts/checkSlug?nama_kebutuhan=' + nama_kebutuhan.value)
        .then(response => response.json())
        .then(data => slug.value = data.slug) });
</script>

@endsection
