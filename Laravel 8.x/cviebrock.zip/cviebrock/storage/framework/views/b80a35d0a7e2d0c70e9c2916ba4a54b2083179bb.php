
<?php $__env->startSection('container'); ?>
<div class="container mt-4">
	<div class="d-flex justify-content-end">
        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-success mb-2">Tambah Role</a>
	</div>
	<div class="mt-3">
			<?php if(session('success')): ?>
				<div class="alert alert-success">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?>
			
			<?php if(session('error')): ?>
                <div class="alert alert-error">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
		 <table class="table table-hover" id="users-list">
		   <thead>
			  <tr>
				 <th>Role Id</th>
				 <th>Jenis Role</th>
				 <th>Jenis Kelamin</th>
				 <th>Umur</th>
				 <th>Aksi</th>
			  </tr>
		   </thead>
		   <tbody>
			 <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			  <tr>
				 <td><?php echo e($student->id); ?></td>
				 <td><?php echo e($student->nama); ?></td>
				 <td><?php echo e($student->jenis_kelamin); ?></td>
				 <td><?php echo e($student->umur); ?></td>
				 <td>
					<form onsubmit="return confirm('Apakah Anda Yakin ?');"
						action="<?php echo e(route('student.destroy', $student->id)); ?>" method="POST">
						<a href="<?php echo e(route('student.edit', $student->id)); ?>"
							class="btn btn-sm btn-primary">EDIT</a>
						<?php echo csrf_field(); ?>
						<?php echo method_field('DELETE'); ?>
						<button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
					</form>
					
				  </td>
			  </tr>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<tr>
					<td class="text-center text-mute" colspan="5">Data Kosong</td>
				</tr>
			 <?php endif; ?>
		   </tbody>
		 </table>
	  </div>
</div>
<script>
    $(document).ready( function () {
      $('#students-list').DataTable();
  } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/students/index.blade.php ENDPATH**/ ?>