<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Pesanan Baru</h1>

  </div>


<div class="col-lg-8">

    <form method="post" action="/dashboard/posts" class="mb-5">
        <?php echo csrf_field(); ?>


        <div class="mb-3">
            <label for="category" class="form-label">Nama Divisi</label>
            <select class="form-select" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(old('category_id') == $category->id): ?>
            <option value ="<?php echo e($category->id); ?>" selected><?php echo e($category->nama_divisi); ?></option>
                <?php else: ?>
                <option value ="<?php echo e($category->id); ?>"><?php echo e($category->nama_divisi); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>

          <div class="mb-3">
            <label for="nama_kebutuhan" class="form-label">Nama Kebutuhan</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nama_kebutuhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_kebutuhan"
            name="nama_kebutuhan" required autofocus value="<?php echo e(old('nama_kebutuhan')); ?>">
            <?php $__errorArgs = ['nama_kebutuhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
            <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <div class="mb-3">
            <label for="slug" class="form-label">Kode</label>
            <input type="text" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
            name="slug" required autofocus value="<?php echo e(old('slug')); ?>">
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
            <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>




          <div class="mt-3">
            <label for="category" class="form-label">Kategori Pesanan</label>
            <select class="form-select" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(old('category_id') == $category->id): ?>
            <option value ="<?php echo e($category->id); ?>" selected><?php echo e($category->kategori_pesanan); ?></option>
                <?php else: ?>
                <option value ="<?php echo e($category->id); ?>"><?php echo e($category->kategori_pesanan); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>




          <div class="mb-3">
            <label for="jumlah_kebutuhan" class="form-label">Jumlah_Kebutuhan</label>
            <input type="text" class="form-control <?php $__errorArgs = ['jumlah_kebutuhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah_kebutuhan"
            name="jumlah_kebutuhan" required autofocus value="<?php echo e(old('jumlah_kebutuhan')); ?>">
            <?php $__errorArgs = ['jumlah_kebutuhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
            <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" class="form-control <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga"
            name="harga" required autofocus value="<?php echo e(old('harga')); ?>">
            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
            <?php echo e($message); ?>

          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <div class="mt-3">
            <label for="body" class="form-label">Keterangan / Penjelasan</label>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input id="body" type="hidden" name="body" value="<?php echo e(old('body')); ?>">
            <trix-editor input="body"></trix-editor>
          </div>

        <div class="mb-3 form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Buat Pesanan Baru</button>
      </form>

</div>

<script>
  const nama_kebutuhan = document.querySelector('#nama_kebutuhan');
  const slug = document.querySelector('#slug');

  nama_kebutuhan.addEventListener('change' , function(){
      fetch('/dashboard/posts/checkSlug?nama_kebutuhan=' + nama_kebutuhan.value)
      .then(response => response.json())
      .then(data => slug.value = data.slug) });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/dashboard/posts/create.blade.php ENDPATH**/ ?>