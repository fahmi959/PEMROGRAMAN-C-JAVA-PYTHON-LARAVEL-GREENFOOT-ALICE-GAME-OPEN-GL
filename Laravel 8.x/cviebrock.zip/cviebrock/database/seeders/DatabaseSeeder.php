<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Post;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {


        // User::create([
        //     'name' => 'Fahmi Ardiansyah',
        //     'level' => 'Admin' ,
        //     'email' => 'fahmiardiansyah959@students.unnes.ac.id',
        //     'password' => bcrypt('root')
        // ]);

        User::create([
            'name' => 'Lord Baelah',
            'level' => 'Admin' ,
            'email' => 'fahmilord959@gmail.com',
            'password' => bcrypt('Fahmi54321')
        ]);

        // User::factory(5)->create();




        Category::create ([
            'name' => 'Web Programming',

            'nama_divisi' => 'CRM',
            'kategori_pesanan' => 'Makanan',
            'slug' => 'makanan'
        ]);

        Category::create ([
            'name' => 'Personal',

            'nama_divisi' => 'SistemX',
            'kategori_pesanan' => 'Teknologi',
            'slug' => 'teknologi'
        ]);

        Category::create ([
            'name' => 'Web Design',

            'nama_divisi' => 'SOA',
            'kategori_pesanan' => 'Aksesoris',
            'slug' => 'aksesoris'
        ]);

        Category::create ([
            'name' => 'Fashion',

            'nama_divisi' => 'Sales',
            'kategori_pesanan' => 'Pakaian',
            'slug' => 'pakaian'
        ]);

        Category::create ([
            'name' => 'Book',

            'nama_divisi' => 'SDM',
            'kategori_pesanan' => 'Buku',
            'slug' => 'buku'
        ]);




        Post::factory(2) ->create();

        // Post::create ([
        //     'title' => 'Judul Pertama',
        //     'slug' => 'judul-pertama' ,
        //     'excerpt' => ' Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,
        //     'body' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,

        //     'category_id' => 1 ,
        //     'user_id' => 1
        // ]);

        // Post::create ([
        //     'title' => 'Judul Kedua',
        //     'slug' => 'judul-kedua' ,
        //     'excerpt' => ' Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,
        //     'body' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,

        //     'category_id' => 1 ,
        //     'user_id' => 2
        // ]);

        // Post::create ([
        //     'title' => 'Judul Ketiga',
        //     'slug' => 'judul-ketiga' ,
        //     'excerpt' => ' Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,
        //     'body' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,

        //     'category_id' => 2 ,
        //     'user_id' => 2
        // ]);

        // Post::create ([
        //     'title' => 'Judul Keempat',
        //     'slug' => 'judul-keempat' ,
        //     'excerpt' => ' Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,
        //     'body' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.
        //     Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda voluptas molestiae labore expedita culpa unde numquam, temporibus adipisci totam voluptatem eveniet doloremque sit, inventore ea vitae dolorum facere eligendi exercitationem.' ,

        //     'category_id' => 2 ,
        //     'user_id' => 1
        // ]);

    }
}

