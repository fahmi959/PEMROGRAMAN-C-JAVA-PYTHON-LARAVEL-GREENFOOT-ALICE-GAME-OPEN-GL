<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>DATA INVOICE</title>
    </head>

    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data Invoice - <strong>EDIT DATA</strong>
                </div>

                <div class="card-body">
                    <a href="/invoice" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    <form method="post" action="/invoice/update/{{ $invoice->id}}">
                        {{ csrf_field() }}
                        {{ method_field('PUT') }}

                        <div class="form-group">
                            <label>Id Invoice</label>
                            <input type="text" name="Kode_invoice" class="form-control" placeholder="Id Invoice" value=" {{ $invoice->Kode_invoice }}">
                            @if($errors->has('Kode_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Kode_invoice')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Id Pelanggan</label>
                            <input type="text" name="Id_pelanggan" class="form-control" placeholder="Id Pelanggan" value=" {{ $invoice->Id_pelanggan }}">
                            @if($errors->has('Id_pelanggan'))
                                <div class="text-danger">
                                    {{ $errors->first('Id_pelanggan')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="Nama_invoice" class="form-control" placeholder="Nama Barang ..." value=" {{ $invoice->Nama_invoice }}">
                            @if($errors->has('Nama_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Nama_invoice')}}
                                </div>
                            @endif
                        </div>
                        
                        <div class="form-group">
                            <label>Jumlah</label>
                            <textarea name="Jumlah_invoice" class="form-control" placeholder="Jumlah  ..."> {{ $invoice->Jumlah_invoice }} </textarea>
                            @if($errors->has('Jumlah_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Jumlah_invoice')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Harga Invoice</label>
                            <textarea name="Harga_invoice" class="form-control" placeholder="Harga  ..."> {{ $invoice->Harga_invoice }} </textarea>
                            @if($errors->has('Harga_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Harga_invoice')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Ppn</label>
                            <input type="text" name="Ppn_invoice" class="form-control" placeholder="Ppn" value=" {{ $invoice->Ppn_invoice }}">
                            @if($errors->has('Ppn_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Ppn_invoice')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Total</label>
                            <input type="text" name="Total_invoice" class="form-control" placeholder="Total" value=" {{ $invoice->Total_invoice }}">
                            @if($errors->has('Total_invoice'))
                                <div class="text-danger">
                                    {{ $errors->first('Total_invoice')}}
                                </div>
                            @endif
                        </div>
                        
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>

