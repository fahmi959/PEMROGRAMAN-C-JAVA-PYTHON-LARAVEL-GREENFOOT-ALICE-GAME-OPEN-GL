@extends('dashboard.layouts.main')
@section('container')

    <div class="container mt-5">
        @if (session('error'))
        <div class="alert alert-error">
            {{ session('error') }}
        </div>
        @endif

        <h2>Tambah Role</h2>
        <form method="post" id="add_create" name="add_create" action="{{ route('student.store') }}">
            @csrf
            <div class="form-group">
                <label>Jenis Role</label>
                <select name="nama" class="form-control" required>
                    <option value="Admin" selected>Admin</option>
                    <option value="User">User</option>
                </select>

                @error('name')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-control" required>
                    <option value="Male" selected>laki-laki</option>
                    <option value="Female">Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label>Umur</label>
                <input type="text" name="umur" class="form-control" value="{{ old('umur') }}" required>

                @error('age')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>
            <br />

            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Tambah Data</button>
                <a href="{{ route('student.index') }}" class="btn btn-md btn-secondary">back</a>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

@endsection