<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>CRUD</title>
    </head>
    
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    Data Invoice
                    <form action="/invoice/cari" method="GET">
                        <input type="text" name="cari" placeholder="Cari Invoice .." value="<?php echo e(old('cari')); ?>">
                        <input type="submit" value="CARI">
                    </form>
                </div>
                
                <div class="card-body">
                    <a href="/invoice/tambah" class="btn btn-primary">Input Invoice Baru</a>
                    <br/>
                    <br/>
                    
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Id Invoice</th>
                                <th>Id Pelanggan</th>
                                <th>Nama</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Ppn</th>
                                <th>Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->Kode_invoice); ?></td>
                                <td><?php echo e($p->Id_pelanggan); ?></td>
                                <td><?php echo e($p->Nama_invoice); ?></td>
                                <td><?php echo e($p->Jumlah_invoice); ?></td>
                                <td><?php echo e($p->Harga_invoice); ?></td>
                                <td><?php echo e($p->Ppn_invoice); ?></td>
                                <td><?php echo e($p->Total_invoice); ?></td>

                                <td> 
                                    <a href="/invoice/edit/<?php echo e($p->id); ?>" class="btn btn-warning">Edit</a>
                                    <a href="/invoice/hapus/<?php echo e($p->id); ?>" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br/>
                    Halaman : <?php echo e($invoice->currentPage()); ?> <br/>
                    Jumlah Data : <?php echo e($invoice->total()); ?> <br/>
                    Data Per Halaman : <?php echo e($invoice->perPage()); ?> <br/>
                    <?php echo e($invoice->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>


<?php /**PATH D:\PENGHASIL PROGRAM C++, JAVA, PYTHON, LARAVEL\Laravel 8.x\Sayang\resources\views/invoice.blade.php ENDPATH**/ ?>