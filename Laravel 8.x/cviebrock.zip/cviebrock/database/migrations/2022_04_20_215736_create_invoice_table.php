<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInvoiceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoice', function (Blueprint $table) {
            $table->id();
            $table->integer('Kode_invoice');
            $table->integer('Id_pelanggan')->nullable();
            $table->string('Nama_invoice');
            $table->integer('Jumlah_invoice');
            $table->bigInteger('Harga_invoice');
            $table->integer('Ppn_invoice');
            $table->integer('Total_invoice');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoice');
    }
}


