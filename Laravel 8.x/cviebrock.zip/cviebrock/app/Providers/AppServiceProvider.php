<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use App\Models\User;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Gate;

use function PHPUnit\Framework\returnValue;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();

        Gate::define('ceo', function (User $user) {
            // return $user->username === 'fahmi';
            return $user->email === 'fahmiardiansyah959@students.unnes.ac.id';
    });

    //     Gate::define('manajer_eksekutif', function (User $user) {
    //         return $user->email === 'ahmadsyafii2751@students.unnes.ac.id';
    // });

    Gate::define('admin', function (User $user) {

        return $user->level === 'admin' | $user->email === 'ahmadsyafii2751@students.unnes.ac.id' | $user->email === 'yusufridwanallatif@students.unnes.ac.id'
        |$user->email === 'amanullahabyan@students.unnes.ac.id' | $user->email === 'nurulnur061203@gmail.com' ;

});



Gate::define('manajer_eksekutif', function (User $user) {

    return $user->level === 'manajer_eksekutif';
});
Gate::define('vendor', function (User $user) {
    // return $user->username === 'fahmi';
    return $user->level === 'vendor';
});


    }
}
