<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;

    protected $table = "invoice";

    protected $fillable = ['Kode_invoice','Id_pelanggan', 'Nama_invoice','Jumlah_invoice', 'Harga_invoice','Ppn_invoice','Total_invoice'];
}
