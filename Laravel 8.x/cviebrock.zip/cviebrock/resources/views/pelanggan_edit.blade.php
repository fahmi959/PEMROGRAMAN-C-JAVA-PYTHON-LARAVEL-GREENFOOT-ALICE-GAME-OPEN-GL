<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>DATA PELANGGAN</title>
    </head>

    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data Pelanggan - <strong>EDIT DATA</strong>
                </div>

                <div class="card-body">
                    <a href="/pelanggan" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    <form method="post" action="/pelanggan/update/{{ $pelanggan->id}}">
                        {{ csrf_field() }}
                        {{ method_field('PUT') }}

                        <div class="form-group">
                            <label>Id Pelanggan</label>
                            <input type="text" name="Kode_pelanggan" class="form-control" placeholder="Id Pelanggan" value=" {{ $pelanggan->Kode_pelanggan }}">
                            @if($errors->has('Kode_pelanggan'))
                                <div class="text-danger">
                                    {{ $errors->first('Kode_pelanggan')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" name="Nama_pelanggan" class="form-control" placeholder="Nama Pelanggan ..." value=" {{ $pelanggan->Nama_pelanggan }}">
                            @if($errors->has('Nama_pelanggan'))
                                <div class="text-danger">
                                    {{ $errors->first('Nama_pelanggan')}}
                                </div>
                            @endif
                        </div>
                        
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="Alamat_pelanggan" class="form-control" placeholder="Alamat Pelanggan ..."> {{ $pelanggan->Alamat_pelanggan }} </textarea>
                            @if($errors->has('Alamat_pelanggan'))
                                <div class="text-danger">
                                    {{ $errors->first('Alamat_pelanggan')}}
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Telepon Pelanggan</label>
                            <textarea name="Telpon_pelanggan" class="form-control" placeholder="Telepon Pelanggan ..."> {{ $pelanggan->Telpon_pelanggan }} </textarea>
                            @if($errors->has('Telpon_pelanggan'))
                                <div class="text-danger">
                                    {{ $errors->first('Telpon_pelanggan')}}
                                </div>
                            @endif
                        </div>
                        
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>