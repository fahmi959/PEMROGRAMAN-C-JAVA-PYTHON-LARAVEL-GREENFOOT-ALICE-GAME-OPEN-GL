<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>CRUD</title>
    </head>
    
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    Data Invoice
                    <form action="/invoice/cari" method="GET">
                        <input type="text" name="cari" placeholder="Cari Invoice .." value="{{ old('cari') }}">
                        <input type="submit" value="CARI">
                    </form>
                </div>
                
                <div class="card-body">
                    <a href="/invoice/tambah" class="btn btn-primary">Input Invoice Baru</a>
                    <br/>
                    <br/>
                    
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Id Invoice</th>
                                <th>Id Pelanggan</th>
                                <th>Nama</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Ppn</th>
                                <th>Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            @foreach($invoice as $p)
                            <tr>
                                <td>{{ $p->Kode_invoice  }}</td>
                                <td>{{ $p->Id_pelanggan  }}</td>
                                <td>{{ $p->Nama_invoice }}</td>
                                <td>{{ $p->Jumlah_invoice }}</td>
                                <td>{{ $p->Harga_invoice  }}</td>
                                <td>{{ $p->Ppn_invoice  }}</td>
                                <td>{{ $p->Total_invoice  }}</td>

                                <td> 
                                    <a href="/invoice/edit/{{ $p->id }}" class="btn btn-warning">Edit</a>
                                    <a href="/invoice/hapus/{{ $p->id }}" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <br/>
                    Halaman : {{ $invoice->currentPage() }} <br/>
                    Jumlah Data : {{ $invoice->total() }} <br/>
                    Data Per Halaman : {{ $invoice->perPage() }} <br/>
                    {{ $invoice->links() }}
                </div>
            </div>
        </div>
    </body>
</html>


