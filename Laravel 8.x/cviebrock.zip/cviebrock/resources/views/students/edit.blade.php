@extends('dashboard.layouts.main')
@section('container')

<div class="container mt-5">
    @if (session('error'))
    <div class="alert alert-error">
        {{ session('error') }}
    </div>
    @endif

    <h2>Edit Role</h2>
    <form method="post" id="add_create" name="add_create" action="{{ route('student.update', $student->id) }}">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label>Jenis Role</label>
            <select name="jenis_kelamin" class="form-control" required>
                <option value="Admin" {{ $student->nama == 'Admin' ? 'selected':'' }}>Admin</option>
                <option value="User" {{ $student->nama == 'User' ? 'selected':'' }}>User</option>
            </select>

            @error('nama')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control" required>

                <option value="Male" {{ $student->jenis_kelamin == 'laki-laki' ? 'selected':'' }}>laki-laki</option>
                <option value="Female" {{ $student->jenis_kelamin == 'Perempuan' ? 'selected':'' }}>Perempuan</option>
            </select>
        </div>

        <div class="form-group">
            <label>Umur</label>
            <input type="text" name="umur" class="form-control" value="{{ old('umur', $student->umur) }}" required>

            @error('umur')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>
        <br />

        <div class="form-group">
            <button type="submit" class="btn btn-md btn-primary">Update Data</button>
            <a href="{{ route('student.index') }}" class="btn btn-md btn-secondary">back</a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

@endsection